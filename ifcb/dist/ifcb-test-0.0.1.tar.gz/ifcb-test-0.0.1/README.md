# ifcb

Command-line api for accessing data in Imaging FlowCytobot database (WHOI-Plankton)
